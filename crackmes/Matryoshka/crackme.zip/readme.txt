first crackme ive ever made.
its really easy, dont give up!!!!!
i did not add any "flags", when you solve it its supposed to print the line "u win good job!!!"
